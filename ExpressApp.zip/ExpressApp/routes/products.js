const express = require("express");
const router = express.Router();
const Product = require("../models/Product");

// PRODUCT LIST WITH PAGINATION + FILTERS
router.get("/", async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 6;

  const category = req.query.category;
  const minPrice = req.query.minPrice;
  const maxPrice = req.query.maxPrice;

  let query = {};

  if (category) query.category = category;
  if (minPrice || maxPrice) {
    query.price = {};
    if (minPrice) query.price.$gte = minPrice;
    if (maxPrice) query.price.$lte = maxPrice;
  }

  const total = await Product.countDocuments(query);

  const products = await Product.find(query)
    .skip((page - 1) * limit)
    .limit(limit);

  res.render("products", {
    products,
    page,
    totalPages: Math.ceil(total / limit),
    category,
    minPrice,
    maxPrice
  });
});

module.exports = router;
